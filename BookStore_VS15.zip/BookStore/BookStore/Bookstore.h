#pragma once

#ifdef BOOKSTORE_EXPORTS
#define MATHLIBRARY_API __declspec(dllexport)
#else
#define MATHLIBRARY_API __declspec(dllimport)
#endif

#ifndef BOOKSTORE_H
#define BOOKSTORE_H
#include"Book.h"
#include"ManagementBook.h"
#include"TechnicalBook.h"
#include<map>

struct cmp_str
{
   bool operator()(char const *a, char const *b) const
   {
      return std::strcmp(a, b) < 0;
   }
};

class Bookstore {
private:
	map<char*, Book*, cmp_str> books;
public:
	MATHLIBRARY_API Bookstore();
	MATHLIBRARY_API void addBook();
	MATHLIBRARY_API void displayBooks();
	MATHLIBRARY_API void searchBook();
	MATHLIBRARY_API ~Bookstore();
};
#endif